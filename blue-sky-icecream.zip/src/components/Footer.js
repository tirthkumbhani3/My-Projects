import React from 'react';

function Footer() {
  return (
    <footer>
      <p>&copy; 2025 Blue Sky Summer. All rights reserved.</p>
    </footer>
  );
}

export default Footer;