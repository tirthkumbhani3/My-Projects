import React from 'react';

function Header() {
  return (
    <header>
      <h1>Blue Sky Summer</h1>
      {/* Add navbar or logo here */}
    </header>
  );
}

export default Header;