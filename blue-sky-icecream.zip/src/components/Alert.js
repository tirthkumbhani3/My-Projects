import React from 'react';

function Alert() {
  return null; // Add SweetAlert or any alert logic here
}

export default Alert;