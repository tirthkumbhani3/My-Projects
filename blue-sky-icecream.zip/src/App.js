import React, { useEffect } from 'react';
import './App.css'; // Assume your CSS is converted to App.css or a module
import { Header, Footer, Alert } from './components';

function App() {
  useEffect(() => {
    // If you have slider logic from user_script.js, place here
  }, []);

  return (
    <div className="App">
      <Header />

      {/* Slider Section */}
      <section className="slider-container">
        <div className="slideBox active">
          <div className="textBox">
            <h1>we pride ourselves on <br /> exceptional flavors</h1>
            <a href="/menu" className="btn">shop now</a>
          </div>
          <div className="imgBox">
            <img src="/image/slider.jpg" alt="Slider" />
          </div>
        </div>
        <ul className="controls">
          <li className="next"><i className='bx bx-right-arrow-alt'></i></li>
          <li className="prev"><i className='bx bx-left-arrow-alt'></i></li>
        </ul>
      </section>

      {/* Services */}
      <section className="service">
        <div className="box-container">
          {[...Array(6)].map((_, i) => (
            <div className="box" key={i}>
              <div className="icon">
                <div className="icon-box">
                  <img src={`/image/services${i % 2 ? ' (1)' : ''}.png`} className="img1" alt="icon" />
                  <img src={`/image/services${i % 2 ? ' (1)' : ''}.png`} className="img2" alt="icon-hover" />
                </div>
              </div>
              <div className="detail">
                <h4>delivery</h4>
                <span>100% secure</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="categories">
        <div className="heading">
          <h1><strong>categories features</strong></h1>
          <img src="/image/separator-img.png" alt="separator" />
        </div>
        <div className="box-container">
          {['coconuts', 'chocolate', 'strawberry', 'corn'].map((flavor, i) => (
            <div className="box" key={i}>
              <img src={`/image/categories${i === 0 ? '' : i}.jpg`} alt={flavor} />
              <a href="/menu" className="btn">{flavor}</a>
            </div>
          ))}
        </div>
      </section>

      {/* Taste */}
      <section className="taste">
        <div className="heading">
          <span>Taste</span>
          <h1>buy any ice cream @ get one free</h1>
          <img src="/image/separator-img.png" alt="separator" />
        </div>
        <div className="box-container">
          {['vanila', 'matcha', 'blueberry'].map((flavor, i) => (
            <div className="box" key={i}>
              <img src={`/image/taste${i === 0 ? '' : i}.webp`} alt={flavor} />
              <div className="detail">
                <h2>natural sweetness</h2>
                <h1>{flavor}</h1>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Ice Container */}
      <section className="ice-container">
        <div className="overlay"></div>
        <div className="detail">
          <h1>Ice cream is cheaper than <br /> therapy for stress</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
          <a href="/menu" className="btn">shop now</a>
        </div>
      </section>

      {/* Taste 2 */}
      <section className="taste2">
        <div className="t-banner">
          <div className="overlay"></div>
          <div className="detail">
            <h1>find your taste of desserts</h1>
            <p>Treat them to a delicious treat...</p>
            <a href="/menu" className="btn">shop now</a>
          </div>
        </div>
        <div className="box-container">
          {[...Array(6)].map((_, i) => (
            <div className="box" key={i}>
              <div className="box-overlay"></div>
              <img src={`/image/type${i === 1 ? '' : i}.avif`} alt="dessert" />
              <div className="box-details fadeIn-bottom">
                <h1>strawberry</h1>
                <p>find your taste of desserts</p>
                <a href="/menu" className="btn">explore more</a>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Flavor Sale Banner */}
      <section className="flavor">
        <div className="box-container">
          <img src="/image/left-banner2.webp" alt="sale" />
          <div className="detail">
            <h1>Hot Deal ! Sale Up To <span>20% off</span></h1>
            <p>expired</p>
            <a href="/menu" className="btn">shop now</a>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="usage">
        <div className="heading">
          <h1>how it works</h1>
          <img src="/image/separator-img.png" alt="separator" />
        </div>
        {/* Repeatable rows */}
        <div className="row">
          <div className="box-container">
            {/* Add each how-it-works item manually or with a map */}
          </div>
        </div>
      </section>

      {/* Pride Section */}
      <section className="pride">
        <div className="detail">
          <h1>We Pride Ourselves On <br /> Exceptional Flavors.</h1>
          <p>Crafted with passion, perfected with care...</p>
          <a href="/menu" className="btn">shop now</a>
        </div>
      </section>

      <Footer />
      <Alert />
    </div>
  );
}

export default App;